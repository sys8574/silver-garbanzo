# Railway Telegram Bot

A simple Telegram bot deployed on Railway.

## Setup

1. Clone the repository.
2. Rename `.env.example` to `.env` and add your bot token.
3. Deploy the project on Railway.

## Start the Bot

```sh
npm install
npm start
```

